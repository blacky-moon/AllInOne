package miyucomics.hexpose.actions.identifier

import at.petrak.hexcasting.api.casting.castables.ConstMediaAction
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.IotaType
import miyucomics.hexpose.iotas.asActionResult
import net.minecraft.registry.Registries
import net.minecraft.registry.Registry
import net.minecraft.util.Identifier

@Suppress("UNCHECKED_CAST")
val iotaTypeRegistry = (Registries.REGISTRIES.get(Identifier("hexcasting", "iota_type"))) as Registry<IotaType<*>>

object OpClassify : ConstMediaAction {
	override val argc = 1
	override fun execute(args: List<Iota>, env: CastingEnvironment) =
		iotaTypeRegistry.getId(args[0].type)!!.asActionResult
}
