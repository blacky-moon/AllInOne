package miyucomics.hexpose.actions.misc

import at.petrak.hexcasting.api.casting.asActionResult
import at.petrak.hexcasting.api.casting.castables.ConstMediaAction
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.NullIota
import at.petrak.hexcasting.api.casting.mishaps.MishapBadCaster
import at.petrak.hexcasting.xplat.IXplatAbstractions
import net.minecraft.server.network.ServerPlayerEntity
import net.minecraft.util.math.Vec3d

object OpGetFlightOrigin : ConstMediaAction {
    override val argc = 0
    override fun execute(args: List<Iota>, env: CastingEnvironment): List<Iota> {
        val entity = env.castingEntity
        if (entity !is ServerPlayerEntity)
            throw MishapBadCaster()

        val flight = IXplatAbstractions.INSTANCE.getFlight(entity)
            ?: return listOf(NullIota())

        if (flight.radius < 0.0)
            return listOf(NullIota())

        return flight.origin.asActionResult
    }
}