package io.yukkuric.hexparse.api

import at.petrak.hexcasting.api.casting.castables.SpecialHandler
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.PatternIota
import io.yukkuric.hexparse.misc.IOMethod
import io.yukkuric.hexparse.parsers.ParserMain
import io.yukkuric.hexparse.parsers.nbt2str.INbt2Str
import io.yukkuric.hexparse.parsers.nbt2str.PatternParser
import io.yukkuric.hexparse.parsers.str2nbt.IStr2Nbt
import net.minecraft.world.item.ItemStack

object HexParseAPI {
    @JvmStatic
    fun AddForthParser(p: IStr2Nbt) {
        ParserMain.AddForthParser(p)
    }
    @JvmStatic
    fun AddBackParser(p: INbt2Str<*>) {
        ParserMain.AddBackParser(p)
    }
    @JvmStatic
    fun <T : SpecialHandler> AddSpecialHandlerBackParser(cls: Class<T>, func: (T, PatternIota) -> String) {
        PatternParser.AddSpecialHandlerBackParser(cls, func)
    }
    @JvmStatic
    fun CreateItemIOMethod(
        cls: Class<*>,
        writer: ((ItemStack, Iota) -> Unit)? = null,
        reader: ((ItemStack) -> Iota?)? = null,
        priority: Int = 0,
        validator: ((ItemStack, Boolean) -> Boolean)? = null,
    ) {
        IOMethod(cls, writer, reader, priority, validator)
    }
}