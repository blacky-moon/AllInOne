package io.yukkuric.hexparse.parsers.str2nbt;

import at.petrak.hexcasting.api.casting.iota.*;
import at.petrak.hexcasting.api.casting.math.HexDir;
import io.yukkuric.hexparse.misc.NumEvaluatorBrute;
import io.yukkuric.hexparse.misc.StringEscaper;
import io.yukkuric.hexparse.parsers.IotaFactory;
import net.minecraft.world.phys.Vec3;

import static io.yukkuric.hexparse.parsers.str2nbt.BaseConstParser.*;

public class ConstParsers {
    // prefix
    public static Comment.Indent TO_TAB = new Comment.Indent();
    public static BaseConstParser TO_COMMENT = new Comment("comment_") {
        @Override
        public Iota parse(String node) {
            return IotaFactory.makeComment(node.substring(8));
        }
    };
    public static BaseConstParser TO_SCOMMENT = new Comment("c\"") {
        @Override
        public Iota parse(String node) {
            return IotaFactory.makeComment(
                    // c"<escaped comment contents>"
                    StringEscaper.Companion.unescape(node.substring(1))
            );
        }
    };
    public static BaseConstParser TO_VEC = new Prefix("vec") {
        @Override
        public Iota parse(String node) {
            var frags = node.split("_");
            var axes = new double[3];
            for (var i = 1; i <= 3; i++) {
                axes[i - 1] = 0;
                if (i >= frags.length) continue;
                try {
                    axes[i - 1] = Double.parseDouble(frags[i]);
                } catch (NumberFormatException e) {
                }
            }
            return new Vec3Iota(new Vec3(axes[0], axes[1], axes[2]));
        }
    };
    public static BaseConstParser TO_NUM_PATTERN = new Prefix("num") {
        @Override
        public Iota parse(String node) {
            double num = 0;
            try {
                num = Double.parseDouble(node.split("_")[1]);
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            }
            var seq = NumEvaluatorBrute.getAnglesFromNum(num);
            return IotaFactory.makePattern(seq, num < 0 ? HexDir.NORTH_EAST : HexDir.SOUTH_EAST);
        }
    };

    // regex
    public static BaseConstParser TO_NUM = new Regex("^[0-9.\\-]+(e[0-9.\\-]+)?$") {
        @Override
        public Iota parse(String node) {
            try {
                return IotaFactory.makeNum(Double.parseDouble(node));
            } catch (NumberFormatException e) {
                return IotaFactory.makeNum(Double.NaN);
            }
        }
    };
    public static BaseConstParser TO_RAW_PATTERN = new Regex("^_[wedsaq]*$") {
        @Override
        public Iota parse(String node) {
            return IotaFactory.makePattern(node.substring(1), HexDir.EAST);
        }
    };
    public static BaseConstParser TO_MASK = new Regex("^mask_[-v]+$") {
        @Override
        public Iota parse(String node) {
            var seq = new StringBuilder();
            var line = true;
            var start = HexDir.EAST;
            if (node.charAt(5) == 'v') {
                line = false;
                seq.append('a');
                start = HexDir.SOUTH_EAST;
            }
            for (var c : node.substring(6).toCharArray()) {
                if (c == '-') {
                    seq.append(line ? 'w' : 'e');
                    line = true;
                } else {
                    seq.append(line ? "ea" : "da");
                    line = false;
                }
            }
            return IotaFactory.makePattern(seq.toString(), start);
        }
    };
    public static BaseConstParser TO_NEW_THOTH = new Regex("^(thoth|for_each)(_\\d+)?$") {
        @Override
        public Iota parse(String node) {
            var steps = 0;
            if (node.contains("_")) {
                var tmp = node.split("_");
                steps = Integer.parseInt(tmp[tmp.length - 1]);
            }
            if (steps >= 1024) throw new RuntimeException(String.valueOf(steps));
            var sb = new StringBuilder("waaddw");
            for (int i = 0; i < steps; i++) {
                sb.append(i % 2 == 0 ? "da" : "ad");
            }
            return IotaFactory.makePattern(sb.toString(), HexDir.EAST);
        }
    };
}
